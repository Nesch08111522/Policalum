package com.policalum.erp.application.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

import com.policalum.erp.application.dto.request.ReembolsoRequestDTO;
import com.policalum.erp.application.dto.response.ReembolsoResponseDTO;
import com.policalum.erp.domain.model.Reembolso;

@Mapper(componentModel = "spring")
public interface ReembolsoMapper {
    ReembolsoResponseDTO toResponseDto(Reembolso entity);

    Reembolso toEntity(ReembolsoRequestDTO requestDTO);

    void updateEntityFromDto(ReembolsoRequestDTO dto, @MappingTarget Reembolso entity);
}
