package com.policalum.erp.application.dto.response;

import com.policalum.erp.domain.enums.EstadoReembolso;
import com.policalum.erp.domain.enums.MetodoReembolso;
import com.policalum.erp.domain.model.Cliente;
import com.policalum.erp.domain.model.Devolucion;
import com.policalum.erp.domain.model.Reembolso;
import com.policalum.erp.domain.model.User;
import com.policalum.erp.domain.model.Venta;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public record ReembolsoResponseDTO(
        UUID id,
        Devolucion devolucion,
        Venta venta,
        Cliente cliente,
        BigDecimal montoTotalReembolso,
        MetodoReembolso metodoReembolso,
        String referencia,
        User procesadoPor,
        EstadoReembolso estado,
        LocalDateTime fechaProcesado,
        String observaciones
) {
}
