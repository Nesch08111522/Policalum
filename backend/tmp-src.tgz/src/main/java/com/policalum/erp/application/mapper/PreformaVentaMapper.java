package com.policalum.erp.application.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

import com.policalum.erp.application.dto.request.PreformaVentaRequestDTO;
import com.policalum.erp.application.dto.response.PreformaVentaResponseDTO;
import com.policalum.erp.domain.model.PreformaVenta;

@Mapper(componentModel = "spring")
public interface PreformaVentaMapper {
    PreformaVentaResponseDTO toResponseDto(PreformaVenta entity);

    PreformaVenta toEntity(PreformaVentaRequestDTO requestDTO);

    void updateEntityFromDto(PreformaVentaRequestDTO dto, @MappingTarget PreformaVenta entity);
}
