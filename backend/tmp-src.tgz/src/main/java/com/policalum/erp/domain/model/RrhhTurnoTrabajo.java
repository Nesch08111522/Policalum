package com.policalum.erp.domain.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.annotations.UuidGenerator;
import org.hibernate.type.SqlTypes;
import com.policalum.erp.domain.model.User;
import com.policalum.erp.domain.model.Sede;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "rrhh_turnos_trabajo")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class RrhhTurnoTrabajo {

    @Id
    @GeneratedValue
    @UuidGenerator
    @Column(updatable = false, nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "sede_id", nullable = false)
    private Sede sede;

    @Column(name = "nombre_turno", nullable = false, length = 50)
    private String nombreTurno; // MAÑANA, TARDE, NOCHE

    @Column(name = "hora_inicio", nullable = false)
    private LocalTime horaInicio;

    @Column(name = "hora_fin", nullable = false)
    private LocalTime horaFin;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "dias_semana", nullable = false, columnDefinition = "jsonb")
    private List<String> diasSemana; // ["LUNES","MARTES",...]

    @Column(nullable = false)
    private Boolean activo = true;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
}