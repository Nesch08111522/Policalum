package com.policalum.erp.application.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

import com.policalum.erp.application.dto.request.DevolucionRequestDTO;
import com.policalum.erp.application.dto.response.DevolucionResponseDTO;
import com.policalum.erp.domain.model.Devolucion;

@Mapper(componentModel = "spring")
public interface DevolucionMapper {
    DevolucionResponseDTO toResponseDto(Devolucion entity);

    Devolucion toEntity(DevolucionRequestDTO requestDTO);

    void updateEntityFromDto(DevolucionRequestDTO dto, @MappingTarget Devolucion entity);
}
