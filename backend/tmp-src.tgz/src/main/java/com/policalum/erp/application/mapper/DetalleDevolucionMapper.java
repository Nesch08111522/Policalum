package com.policalum.erp.application.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

import com.policalum.erp.application.dto.request.DetalleDevolucionRequestDTO;
import com.policalum.erp.application.dto.response.DetalleDevolucionResponseDTO;
import com.policalum.erp.domain.model.DetalleDevolucion;

@Mapper(componentModel = "spring")
public interface DetalleDevolucionMapper {
    DetalleDevolucionResponseDTO toResponseDto(DetalleDevolucion entity);

    DetalleDevolucion toEntity(DetalleDevolucionRequestDTO requestDTO);

    void updateEntityFromDto(DetalleDevolucionRequestDTO dto, @MappingTarget DetalleDevolucion entity);
}
