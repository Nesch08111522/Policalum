package com.policalum.erp.infrastructure.repository;

import com.policalum.erp.domain.enums.EstadoCxP;
import com.policalum.erp.domain.model.FinanzasCuentaPorPagar;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface FinanzasCuentaPorPagarRepository extends JpaRepository<FinanzasCuentaPorPagar, UUID> {

    @EntityGraph(attributePaths = {"proveedor", "compra", "sede"})
    @Query("SELECT c FROM FinanzasCuentaPorPagar c WHERE " +
            "(:sedeId IS NULL OR c.sede.id = :sedeId) AND " +
            "(:proveedorId IS NULL OR c.proveedor.id = :proveedorId) AND " +
            "(:estado IS NULL OR c.estado = :estado) AND " +
            "(:soloVencidas IS NULL OR :soloVencidas = false OR " +
            " (c.fechaVencimiento IS NOT NULL AND c.fechaVencimiento < CURRENT_DATE " +
            "  AND c.estado <> com.policalum.erp.domain.enums.EstadoCxP.PAGADO))")
    Page<FinanzasCuentaPorPagar> search(
            @Param("sedeId") UUID sedeId,
            @Param("proveedorId") UUID proveedorId,
            @Param("estado") EstadoCxP estado,
            @Param("soloVencidas") Boolean soloVencidas,
            Pageable pageable);

    Optional<FinanzasCuentaPorPagar> findByCompra_Id(UUID compraId);

    long countByEstado(EstadoCxP estado);
}