package com.policalum.erp.infrastructure.repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.policalum.erp.domain.model.CatalogoFraccion;

@Repository
public interface CatalogoFraccionRepository extends JpaRepository<CatalogoFraccion, UUID> {

    @EntityGraph(attributePaths = "producto")
    @Query("SELECT f FROM CatalogoFraccion f WHERE "
            + "(:productoId IS NULL OR f.producto.id = :productoId) AND "
            + "(:activo IS NULL OR f.activo = :activo) AND "
            + "(:searchTerm IS NULL OR TRIM(:searchTerm) = '' OR "
            + "LOWER(f.nombreFraccion) LIKE LOWER(CONCAT('%', :searchTerm, '%')))")
    Page<CatalogoFraccion> search(@Param("productoId") UUID productoId,
            @Param("activo") Boolean activo,
            @Param("searchTerm") String searchTerm,
            Pageable pageable);

    @EntityGraph(attributePaths = "producto")
    List<CatalogoFraccion> findByProducto_IdAndActivoTrueOrderByFactorDescuentoKardexDesc(UUID productoId);

    @EntityGraph(attributePaths = "producto")
    Optional<CatalogoFraccion> findWithProductoById(UUID id);

    Optional<CatalogoFraccion> findByProducto_IdAndFactorDescuentoKardex(UUID productoId,
            BigDecimal factorDescuentoKardex);

    long countByProducto_Id(UUID productoId);

    long countByActivo(Boolean activo);
}
