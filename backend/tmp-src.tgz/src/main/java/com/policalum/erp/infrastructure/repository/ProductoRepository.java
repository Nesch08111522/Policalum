package com.policalum.erp.infrastructure.repository;

import java.util.Optional;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.policalum.erp.domain.enums.TipoProducto;
import com.policalum.erp.domain.model.Producto;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, UUID> {

    @EntityGraph(attributePaths = { "categoria", "proveedor", "fracciones" })
    @Query("SELECT p FROM Producto p WHERE "
            + "(:searchTerm IS NULL OR TRIM(:searchTerm) = '' OR "
            + "LOWER(p.nombre) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR "
            + "LOWER(COALESCE(p.codigoSku, '')) LIKE LOWER(CONCAT('%', :searchTerm, '%'))) AND "
            + "(:categoriaId IS NULL OR p.categoria.id = :categoriaId) AND "
            + "(:tipo IS NULL OR p.tipo = :tipo) AND "
            + "(:activo IS NULL OR p.activo = :activo) AND "
            + "(:esFraccionable IS NULL OR p.esFraccionable = :esFraccionable)")
    Page<Producto> search(@Param("searchTerm") String searchTerm,
                          @Param("categoriaId") UUID categoriaId,
                          @Param("tipo") TipoProducto tipo,
                          @Param("activo") Boolean activo,
                          @Param("esFraccionable") Boolean esFraccionable,
                          Pageable pageable);

    @Query("SELECT p FROM Producto p "
            + "LEFT JOIN FETCH p.categoria "
            + "LEFT JOIN FETCH p.proveedor "
            + "LEFT JOIN FETCH p.fracciones "
            + "WHERE p.id = :id")
    Optional<Producto> findWithRelationsById(@Param("id") UUID id);

    Optional<Producto> findByCodigoSkuIgnoreCase(String codigoSku);

    boolean existsByCodigoSkuIgnoreCase(String codigoSku);

    boolean existsByIdAndEsFraccionableTrue(UUID id);

    long countByActivo(Boolean activo);

    long countByEsFraccionable(Boolean esFraccionable);

    long countByTipo(TipoProducto tipo);
}