package com.policalum.erp.domain.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import com.policalum.erp.domain.enums.OrigenFondos;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "finanzas_retiros_socio")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class FinanzasRetiroSocio {

    @Id
    @GeneratedValue
    @UuidGenerator
    @Column(updatable = false, nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "admin_id", nullable = false)
    private User admin;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "sede_id", nullable = false)
    private Sede sede;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "turno_caja_id")
    private TurnoCaja turnoCaja;

    @Column(name = "monto_retirado", nullable = false, precision = 12, scale = 2)
    private BigDecimal montoRetirado;

    @Column(name = "origen_fondos", nullable = false, length = 30)
    @Enumerated(EnumType.STRING)
    private OrigenFondos origenFondos;

    @Column(columnDefinition = "TEXT")
    private String descripcion;

    @Column(name = "fecha_retiro")
    private LocalDateTime fechaRetiro = LocalDateTime.now();

}