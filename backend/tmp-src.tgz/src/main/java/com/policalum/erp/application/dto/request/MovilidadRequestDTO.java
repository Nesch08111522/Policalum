package com.policalum.erp.application.dto.request;

import com.policalum.erp.domain.model.Movilidad;
import com.policalum.erp.domain.model.Sede;
import com.policalum.erp.domain.model.User;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public record MovilidadRequestDTO(
        Sede sede,
        String placa,
        String tipo,
        String marca,
        String modelo,
        User conductor,
        Boolean activo
) {
}
