package com.policalum.erp.infrastructure.repository;

import com.policalum.erp.domain.model.Stock;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface StockRepository extends JpaRepository<Stock, UUID> {

    @EntityGraph(attributePaths = {"producto", "almacen"})
    Optional<Stock> findByAlmacen_IdAndProducto_Id(UUID almacenId, UUID productoId);

    @EntityGraph(attributePaths = {"producto", "almacen"})
    List<Stock> findByAlmacen_Id(UUID almacenId);

    @EntityGraph(attributePaths = {"producto", "almacen"})
    List<Stock> findByProducto_Id(UUID productoId);

    @EntityGraph(attributePaths = {"producto", "almacen"})
    @Query("SELECT s FROM Stock s WHERE s.almacen.id = :almacenId AND " +
            "(:searchTerm IS NULL OR LOWER(s.producto.nombre) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR LOWER(s.producto.codigoSku) LIKE LOWER(CONCAT('%', :searchTerm, '%'))) AND " +
            "(:soloBajoStock IS FALSE OR s.cantidad <= s.stockMinimo)")
    Page<Stock> searchByAlmacen(
            @Param("almacenId") UUID almacenId,
            @Param("searchTerm") String searchTerm,
            @Param("soloBajoStock") boolean soloBajoStock,
            Pageable pageable
    );

    @Query("SELECT COUNT(s) FROM Stock s WHERE s.almacen.id = :almacenId AND s.cantidad <= s.stockMinimo")
    long countProductosBajoStockByAlmacen(@Param("almacenId") UUID almacenId);
}