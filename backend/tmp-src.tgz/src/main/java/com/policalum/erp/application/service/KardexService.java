package com.policalum.erp.application.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.policalum.erp.application.dto.request.KardexMovimientoRequestDTO;
import com.policalum.erp.application.dto.request.TransferenciaRequestDTO;
import com.policalum.erp.application.dto.response.KardexMovimientoResponseDTO;

public interface KardexService {

    KardexMovimientoResponseDTO registrarMovimiento(KardexMovimientoRequestDTO dto);

    List<KardexMovimientoResponseDTO> registrarTransferencia(TransferenciaRequestDTO dto);

    Page<KardexMovimientoResponseDTO> searchMovimientos(
            UUID productoId,
            UUID almacenId,
            LocalDateTime fechaInicio,
            LocalDateTime fechaFin,
            Pageable pageable
    );
}