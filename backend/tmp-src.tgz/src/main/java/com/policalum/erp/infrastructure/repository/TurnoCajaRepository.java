package com.policalum.erp.infrastructure.repository;

import com.policalum.erp.domain.enums.EstadoTurno;
import com.policalum.erp.domain.model.TurnoCaja;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TurnoCajaRepository extends JpaRepository<TurnoCaja, UUID> {
    Optional<TurnoCaja> findByUser_IdAndSede_IdAndEstado(UUID userId, UUID sedeId, EstadoTurno estado);
}
