package com.policalum.erp.infrastructure.repository;

import com.policalum.erp.domain.model.DetalleVenta;
import java.util.UUID;
import java.util.List;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetalleVentaRepository extends JpaRepository<DetalleVenta, UUID> {
    @EntityGraph(attributePaths = {"producto", "fraccion", "servicio"})
    List<DetalleVenta> findByVenta_Id(UUID ventaId);
}
