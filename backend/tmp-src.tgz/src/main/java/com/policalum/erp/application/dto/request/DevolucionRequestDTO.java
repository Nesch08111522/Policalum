package com.policalum.erp.application.dto.request;

import com.policalum.erp.domain.enums.EstadoDevolucion;
import com.policalum.erp.domain.model.Cliente;
import com.policalum.erp.domain.model.Devolucion;
import com.policalum.erp.domain.model.Sede;
import com.policalum.erp.domain.model.User;
import com.policalum.erp.domain.model.Venta;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public record DevolucionRequestDTO(
        Venta venta,
        Sede sede,
        User solicitadoPor,
        User aprobadoPor,
        Cliente cliente,
        String motivo,
        EstadoDevolucion estado,
        LocalDateTime fechaSolicitud,
        LocalDateTime fechaResolucion,
        String observacionAdmin
) {
}
