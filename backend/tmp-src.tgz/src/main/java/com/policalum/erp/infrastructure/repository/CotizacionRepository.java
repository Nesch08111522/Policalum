package com.policalum.erp.infrastructure.repository;

import com.policalum.erp.domain.enums.EstadoCotizacion;
import com.policalum.erp.domain.model.Cotizacion;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CotizacionRepository extends JpaRepository<Cotizacion, UUID> {
    @EntityGraph(attributePaths = {"sede", "user", "cliente", "venta"})
    @Query("select c from Cotizacion c where (:clienteId is null or c.cliente.id = :clienteId) and (:sedeId is null or c.sede.id = :sedeId) and (:estado is null or c.estado = :estado) and (:desde is null or c.createdAt >= :desde) and (:hasta is null or c.createdAt <= :hasta)")
    Page<Cotizacion> buscar(@Param("clienteId") UUID clienteId, @Param("sedeId") UUID sedeId,
                            @Param("estado") EstadoCotizacion estado, @Param("desde") LocalDateTime desde,
                            @Param("hasta") LocalDateTime hasta, Pageable pageable);

    @EntityGraph(attributePaths = {"sede", "user", "cliente", "venta"})
    List<Cotizacion> findByEstadoAndFechaVigenciaBefore(EstadoCotizacion estado, LocalDate fecha);

    long countByEstado(EstadoCotizacion estado);
}
