package com.policalum.erp.application.dto.response;

import java.math.BigDecimal;
import java.util.UUID;

public record ResumenCierreCajaDTO(UUID turnoId, BigDecimal montoInicial,
                                   BigDecimal ventasEfectivo, BigDecimal esperado,
                                   BigDecimal declarado, BigDecimal diferencia) { }
