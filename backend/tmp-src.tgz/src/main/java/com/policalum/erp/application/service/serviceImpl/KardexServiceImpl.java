package com.policalum.erp.application.service.serviceImpl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.policalum.erp.application.dto.request.KardexMovimientoRequestDTO;
import com.policalum.erp.application.dto.request.TransferenciaRequestDTO;
import com.policalum.erp.application.dto.response.KardexMovimientoResponseDTO;
import com.policalum.erp.application.mapper.KardexMovimientoMapper;
import com.policalum.erp.application.service.KardexService;
import com.policalum.erp.domain.enums.TipoMovimiento;
import com.policalum.erp.domain.enums.TipoReferencia;
import com.policalum.erp.domain.model.Almacen;
import com.policalum.erp.domain.model.KardexMovimiento;
import com.policalum.erp.domain.model.Producto;
import com.policalum.erp.domain.model.Stock;
import com.policalum.erp.domain.model.User;
import com.policalum.erp.exception.ResourceNotFoundException;
import com.policalum.erp.infrastructure.repository.AlmacenRepository;
import com.policalum.erp.infrastructure.repository.KardexRepository;
import com.policalum.erp.infrastructure.repository.ProductoRepository;
import com.policalum.erp.infrastructure.repository.StockRepository;
import com.policalum.erp.infrastructure.repository.UserRepository;

@Service
public class KardexServiceImpl implements KardexService {

    private final KardexRepository kardexRepository;
    private final StockRepository stockRepository;
    private final ProductoRepository productoRepository;
    private final AlmacenRepository almacenRepository;
    private final UserRepository userRepository;
    private final KardexMovimientoMapper kardexMapper;

    public KardexServiceImpl(
            KardexRepository kardexRepository,
            StockRepository stockRepository,
            ProductoRepository productoRepository,
            AlmacenRepository almacenRepository,
            UserRepository userRepository,
            KardexMovimientoMapper kardexMapper) {
        this.kardexRepository = kardexRepository;
        this.stockRepository = stockRepository;
        this.productoRepository = productoRepository;
        this.almacenRepository = almacenRepository;
        this.userRepository = userRepository;
        this.kardexMapper = kardexMapper;
    }

    @Override
    @Transactional
    public KardexMovimientoResponseDTO registrarMovimiento(KardexMovimientoRequestDTO dto) {
        Producto producto = productoRepository.findById(dto.producto().getId())
                .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado con ID: " + dto.producto().getId()));

        Almacen almacen = almacenRepository.findById(dto.almacen().getId())
                .orElseThrow(() -> new ResourceNotFoundException("Almacén no encontrado con ID: " + dto.almacen().getId()));

        Stock stock = stockRepository.findByAlmacen_IdAndProducto_Id(almacen.getId(), producto.getId())
                .orElseGet(() -> crearStockInicial(producto, almacen));

        BigDecimal stockAnterior = stock.getCantidad() != null ? stock.getCantidad() : BigDecimal.ZERO;
        BigDecimal stockNuevo;

        if (dto.tipoMovimiento() == TipoMovimiento.ENTRADA) {
            stockNuevo = stockAnterior.add(dto.cantidadMovida());
        } else if (dto.tipoMovimiento() == TipoMovimiento.SALIDA) {
            if (stockAnterior.compareTo(dto.cantidadMovida()) < 0) {
                throw new IllegalArgumentException("Stock insuficiente en el almacén. Stock actual: " + stockAnterior);
            }
            stockNuevo = stockAnterior.subtract(dto.cantidadMovida());
        } else {
            stockNuevo = dto.cantidadMovida();
        }

        stock.setCantidad(stockNuevo);
        stockRepository.save(stock);

        User usuario = dto.user() != null ? dto.user() : obtenerUsuarioAutenticado();
        if (usuario == null) {
            throw new IllegalArgumentException("El usuario que realiza la operación es requerido.");
        }

        KardexMovimiento movimiento = KardexMovimiento.builder()
                .producto(producto)
                .almacen(almacen)
                .referenciaId(dto.referenciaId())
                .tipoReferencia(dto.tipoReferencia() != null ? dto.tipoReferencia() : TipoReferencia.AJUSTE)
                .tipoMovimiento(dto.tipoMovimiento())
                .cantidadMovida(dto.cantidadMovida())
                .stockResultante(stockNuevo)
                .user(usuario)
                .observacion(dto.observacion())
                .build();

        KardexMovimiento guardado = kardexRepository.save(movimiento);
        return kardexMapper.toResponseDto(guardado);
    }

    @Override
    @Transactional
    public List<KardexMovimientoResponseDTO> registrarTransferencia(TransferenciaRequestDTO dto) {
        if (dto.almacenOrigenId().equals(dto.almacenDestinoId())) {
            throw new IllegalArgumentException("El almacén de origen y destino no pueden ser el mismo.");
        }

        Producto producto = productoRepository.findById(dto.productoId())
                .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado con ID: " + dto.productoId()));

        Almacen almacenOrigen = almacenRepository.findById(dto.almacenOrigenId())
                .orElseThrow(() -> new ResourceNotFoundException("Almacén de origen no encontrado con ID: " + dto.almacenOrigenId()));

        Almacen almacenDestino = almacenRepository.findById(dto.almacenDestinoId())
                .orElseThrow(() -> new ResourceNotFoundException("Almacén de destino no encontrado con ID: " + dto.almacenDestinoId()));

        User usuario = obtenerUsuarioAutenticado();

        String obsSalida = "Transferencia hacia " + almacenDestino.getNombre()
                + (dto.motivo() != null ? " - " + dto.motivo() : "");

        KardexMovimientoRequestDTO salidaDTO = new KardexMovimientoRequestDTO(
                producto,
                almacenOrigen,
                null,
                TipoReferencia.TRANSFERENCIA,
                TipoMovimiento.SALIDA,
                dto.cantidad(),
                BigDecimal.ZERO,
                usuario,
                obsSalida
        );
        KardexMovimientoResponseDTO salidaResponse = registrarMovimiento(salidaDTO);

        String obsEntrada = "Transferencia desde " + almacenOrigen.getNombre()
                + (dto.motivo() != null ? " - " + dto.motivo() : "");

        KardexMovimientoRequestDTO entradaDTO = new KardexMovimientoRequestDTO(
                producto,
                almacenDestino,
                null,
                TipoReferencia.TRANSFERENCIA,
                TipoMovimiento.ENTRADA,
                dto.cantidad(),
                BigDecimal.ZERO,
                usuario,
                obsEntrada
        );
        KardexMovimientoResponseDTO entradaResponse = registrarMovimiento(entradaDTO);

        return List.of(salidaResponse, entradaResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<KardexMovimientoResponseDTO> searchMovimientos(
            UUID productoId,
            UUID almacenId,
            LocalDateTime fechaInicio,
            LocalDateTime fechaFin,
            Pageable pageable) {

        return kardexRepository.searchMovimientos(productoId, almacenId, fechaInicio, fechaFin, pageable)
                .map(kardexMapper::toResponseDto);
    }

    private Stock crearStockInicial(Producto producto, Almacen almacen) {
        Stock nuevoStock = new Stock();
        nuevoStock.setProducto(producto);
        nuevoStock.setAlmacen(almacen);
        nuevoStock.setCantidad(BigDecimal.ZERO);
        return nuevoStock;
    }

    private User obtenerUsuarioAutenticado() {
        if (SecurityContextHolder.getContext().getAuthentication() == null) {
            return null;
        }
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByEmailAndActivoTrue(email).orElse(null);
    }
}
