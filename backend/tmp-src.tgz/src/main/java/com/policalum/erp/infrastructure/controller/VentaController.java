package com.policalum.erp.infrastructure.controller;

import com.policalum.erp.application.dto.request.RegistrarVentaRequestDTO;
import com.policalum.erp.application.dto.request.AnularVentaRequestDTO;
import com.policalum.erp.application.dto.response.VentaDetalleResponseDTO;
import com.policalum.erp.application.dto.response.VentaListadoResponseDTO;
import com.policalum.erp.application.dto.response.VentaProcesadaResponseDTO;
import com.policalum.erp.application.service.VentaService;
import com.policalum.erp.domain.enums.CanalVenta;
import com.policalum.erp.domain.enums.EstadoVenta;
import java.time.LocalDateTime;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import jakarta.validation.Valid;
import java.net.URI;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
@RequestMapping("/api/v1/ventas")
@RequiredArgsConstructor
public class VentaController {
    private final VentaService ventaService;

    @PostMapping
    public ResponseEntity<VentaProcesadaResponseDTO> registrar(@Valid @RequestBody RegistrarVentaRequestDTO request) {
        VentaProcesadaResponseDTO venta = ventaService.registrar(request);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(venta.id()).toUri();
        return ResponseEntity.created(location).body(venta);
    }

    @GetMapping("/{id}")
    public ResponseEntity<VentaDetalleResponseDTO> obtener(@PathVariable UUID id) { return ResponseEntity.ok(ventaService.obtener(id)); }

    @GetMapping
    public ResponseEntity<Page<VentaListadoResponseDTO>> buscar(
            @RequestParam(required = false) UUID sedeId, @RequestParam(required = false) UUID userId,
            @RequestParam(required = false) UUID clienteId, @RequestParam(required = false) EstadoVenta estado,
            @RequestParam(required = false) CanalVenta canal,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime desde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime hasta,
            @PageableDefault(size = 20, sort = "createdAt") Pageable pageable) {
        return ResponseEntity.ok(ventaService.buscar(sedeId, userId, clienteId, estado, canal, desde, hasta, pageable));
    }

    /** Completed fiscal sales are immutable; this endpoint reverses stock and preserves the audit trail. */
    @PostMapping("/{id}/anulacion")
    public ResponseEntity<VentaProcesadaResponseDTO> anular(@PathVariable UUID id, @Valid @RequestBody AnularVentaRequestDTO request) {
        return ResponseEntity.ok(ventaService.anular(id, request));
    }
}
