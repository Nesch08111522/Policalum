package com.policalum.erp.domain.model;


import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

import org.hibernate.annotations.UuidGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import com.policalum.erp.domain.enums.MetodoReembolso;
import com.policalum.erp.domain.enums.EstadoReembolso;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "reembolsos")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Reembolso {

    @Id
    @GeneratedValue
    @UuidGenerator
    @Column(updatable = false, nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "devolucion_id", nullable = false)
    private Devolucion devolucion;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "venta_id", nullable = false)
    private Venta venta;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    @Column(name = "monto_total_reembolso", nullable = false, precision = 12, scale = 2)
    private BigDecimal montoTotalReembolso;

    @Column(name = "metodo_reembolso", nullable = false, length = 30)
    @Enumerated(EnumType.STRING)
    private MetodoReembolso metodoReembolso;

    @Column(length = 100)
    private String referencia;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "procesado_por", nullable = false)
    private User procesadoPor;

    @Column(nullable = false, length = 20)
    @Enumerated(EnumType.STRING)
    private EstadoReembolso estado = EstadoReembolso.PENDIENTE;

    @Column(name = "fecha_procesado")
    private LocalDateTime fechaProcesado;

    @Column(columnDefinition = "TEXT")
    private String observaciones;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

}