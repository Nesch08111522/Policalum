package com.policalum.erp.application.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

import com.policalum.erp.application.dto.request.OrdenDespachoRequestDTO;
import com.policalum.erp.application.dto.response.OrdenDespachoResponseDTO;
import com.policalum.erp.domain.model.OrdenDespacho;

@Mapper(componentModel = "spring")
public interface OrdenDespachoMapper {
    OrdenDespachoResponseDTO toResponseDto(OrdenDespacho entity);

    OrdenDespacho toEntity(OrdenDespachoRequestDTO requestDTO);

    void updateEntityFromDto(OrdenDespachoRequestDTO dto, @MappingTarget OrdenDespacho entity);
}
