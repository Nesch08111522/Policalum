package com.policalum.erp.domain.model;


import com.policalum.erp.domain.model.Cliente;
import com.policalum.erp.domain.model.Cotizacion;
import com.policalum.erp.domain.model.Sede;
import com.policalum.erp.domain.model.User;
import com.policalum.erp.domain.model.TurnoCaja;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.UuidGenerator;
import com.policalum.erp.domain.enums.EstadoPreforma;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "preformas_venta")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PreformaVenta {

    @Id
    @GeneratedValue
    @UuidGenerator
    @Column(updatable = false, nullable = false)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "sede_id", nullable = false)
    private Sede sede;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cotizacion_id")
    private Cotizacion cotizacion;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "turno_caja_id")
    private TurnoCaja turnoCaja;

    @Column(name = "subtotal_neto_estimado", nullable = false, precision = 12, scale = 2)
    private BigDecimal subtotalNetoEstimado = BigDecimal.ZERO;

    @Column(name = "total_igv_estimado", nullable = false, precision = 12, scale = 2)
    private BigDecimal totalIgvEstimado = BigDecimal.ZERO;

    @Column(name = "total_estimado", nullable = false, precision = 12, scale = 2)
    private BigDecimal totalEstimado;

    @Column(nullable = false, length = 20)
    @Enumerated(EnumType.STRING)
    private EstadoPreforma estado = EstadoPreforma.ABIERTA;

    @Column(name = "fecha_expiracion")
    private LocalDateTime fechaExpiracion;

    @Column(columnDefinition = "TEXT")
    private String observaciones;

    // FK circular — se llena al confirmar
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "venta_id")
    private Venta venta;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    // EstadoPreforma moved to com.policalum.erp.domain.enums.EstadoPreforma
}