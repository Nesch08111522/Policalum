package com.policalum.erp.application.dto.response;

import com.policalum.erp.domain.enums.EstadoProducto;
import com.policalum.erp.domain.model.CatalogoFraccion;
import com.policalum.erp.domain.model.DetalleDevolucion;
import com.policalum.erp.domain.model.DetalleVenta;
import com.policalum.erp.domain.model.Devolucion;
import com.policalum.erp.domain.model.Producto;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public record DetalleDevolucionResponseDTO(
        UUID id,
        Devolucion devolucion,
        DetalleVenta detalleVenta,
        Producto producto,
        CatalogoFraccion fraccion,
        BigDecimal cantidadDevuelta,
        BigDecimal precioUnitarioRef,
        EstadoProducto estadoProducto,
        String observacion
) {
}
