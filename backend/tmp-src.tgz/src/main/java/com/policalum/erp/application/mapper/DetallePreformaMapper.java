package com.policalum.erp.application.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

import com.policalum.erp.application.dto.request.DetallePreformaRequestDTO;
import com.policalum.erp.application.dto.response.DetallePreformaResponseDTO;
import com.policalum.erp.domain.model.DetallePreforma;

@Mapper(componentModel = "spring")
public interface DetallePreformaMapper {
    DetallePreformaResponseDTO toResponseDto(DetallePreforma entity);

    DetallePreforma toEntity(DetallePreformaRequestDTO requestDTO);

    void updateEntityFromDto(DetallePreformaRequestDTO dto, @MappingTarget DetallePreforma entity);
}
