package com.policalum.erp.infrastructure.repository;

import com.policalum.erp.domain.enums.EstadoCompra;
import com.policalum.erp.domain.model.Compra;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface CompraRepository extends JpaRepository<Compra, UUID> {

    @EntityGraph(attributePaths = {"proveedor", "sede", "user"})
    @Query("SELECT c FROM Compra c WHERE " +
            "(:proveedorId IS NULL OR c.proveedor.id = :proveedorId) AND " +
            "(:sedeId IS NULL OR c.sede.id = :sedeId) AND " +
            "(:estado IS NULL OR c.estadoCompra = :estado) AND " +
            "(:desde IS NULL OR c.fechaEmision >= :desde) AND " +
            "(:hasta IS NULL OR c.fechaEmision <= :hasta)")
    Page<Compra> search(
            @Param("proveedorId") UUID proveedorId,
            @Param("sedeId") UUID sedeId,
            @Param("estado") EstadoCompra estado,
            @Param("desde") LocalDate desde,
            @Param("hasta") LocalDate hasta,
            Pageable pageable);

    @Query("SELECT c FROM Compra c " +
            "LEFT JOIN FETCH c.detalles d " +
            "LEFT JOIN FETCH d.producto " +
            "LEFT JOIN FETCH d.fraccion " +
            "LEFT JOIN FETCH d.almacen " +
            "LEFT JOIN FETCH c.adjuntos " +
            "LEFT JOIN FETCH c.proveedor " +
            "LEFT JOIN FETCH c.sede " +
            "LEFT JOIN FETCH c.user " +
            "WHERE c.id = :id")
    Optional<Compra> findWithDetailsById(@Param("id") UUID id);

    @Query("SELECT COALESCE(MAX(CAST(SUBSTRING(c.numeroOrdenCompra, 9, 4) AS int)), 0) " +
            "FROM Compra c WHERE c.numeroOrdenCompra LIKE CONCAT('OC-', :year, '-%')")
    Integer findMaxCorrelativoByYear(@Param("year") int year);

    long countByEstadoCompra(EstadoCompra estado);

    @EntityGraph(attributePaths = {"proveedor", "sede", "user"})
    Page<Compra> findByEstadoCompraOrderByCreatedAtDesc(EstadoCompra estado, Pageable pageable);
}