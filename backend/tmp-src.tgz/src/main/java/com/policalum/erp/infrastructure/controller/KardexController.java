package com.policalum.erp.infrastructure.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.policalum.erp.application.dto.request.KardexMovimientoRequestDTO;
import com.policalum.erp.application.dto.request.TransferenciaRequestDTO;
import com.policalum.erp.application.dto.response.KardexMovimientoResponseDTO;
import com.policalum.erp.application.service.KardexService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/kardex")
public class KardexController {

    private final KardexService kardexService;

    public KardexController(KardexService kardexService) {
        this.kardexService = kardexService;
    }

    @PostMapping("/movimientos")
    public ResponseEntity<KardexMovimientoResponseDTO> registrarMovimiento(
            @Valid @RequestBody KardexMovimientoRequestDTO dto) {
        KardexMovimientoResponseDTO response = kardexService.registrarMovimiento(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PostMapping("/transferencias")
    public ResponseEntity<List<KardexMovimientoResponseDTO>> registrarTransferencia(
            @Valid @RequestBody TransferenciaRequestDTO dto) {
        List<KardexMovimientoResponseDTO> response = kardexService.registrarTransferencia(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping
    public ResponseEntity<Page<KardexMovimientoResponseDTO>> searchMovimientos(
            @RequestParam(required = false) UUID productoId,
            @RequestParam(required = false) UUID almacenId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fechaInicio,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fechaFin,
            @PageableDefault(size = 20) Pageable pageable) {

        Page<KardexMovimientoResponseDTO> response = kardexService.searchMovimientos(
                productoId, almacenId, fechaInicio, fechaFin, pageable);
        return ResponseEntity.ok(response);
    }
}