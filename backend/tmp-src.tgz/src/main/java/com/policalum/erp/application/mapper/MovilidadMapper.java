package com.policalum.erp.application.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

import com.policalum.erp.application.dto.request.MovilidadRequestDTO;
import com.policalum.erp.application.dto.response.MovilidadResponseDTO;
import com.policalum.erp.domain.model.Movilidad;

@Mapper(componentModel = "spring")
public interface MovilidadMapper {
    MovilidadResponseDTO toResponseDto(Movilidad entity);

    Movilidad toEntity(MovilidadRequestDTO requestDTO);

    void updateEntityFromDto(MovilidadRequestDTO dto, @MappingTarget Movilidad entity);
}
