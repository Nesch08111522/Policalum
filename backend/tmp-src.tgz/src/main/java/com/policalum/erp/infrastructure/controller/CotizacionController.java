package com.policalum.erp.infrastructure.controller;

import com.policalum.erp.application.dto.request.ConvertirCotizacionRequestDTO;
import com.policalum.erp.application.dto.request.CotizacionRequestDTO;
import com.policalum.erp.application.dto.request.RechazarCotizacionRequestDTO;
import com.policalum.erp.application.dto.response.CotizacionListadoDTO;
import com.policalum.erp.application.dto.response.CotizacionResponseDTO;
import com.policalum.erp.application.dto.response.VentaProcesadaResponseDTO;
import com.policalum.erp.application.service.CotizacionService;
import com.policalum.erp.domain.enums.EstadoCotizacion;
import jakarta.validation.Valid;
import java.net.URI;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
@RequestMapping("/api/v1/cotizaciones")
@RequiredArgsConstructor
public class CotizacionController {
    private final CotizacionService cotizacionService;

    /** Creates an issued quotation with server-calculated amounts. */
    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'MULTIFUNCIONAL')")
    public ResponseEntity<CotizacionResponseDTO> create(@Valid @RequestBody CotizacionRequestDTO request) {
        CotizacionResponseDTO response = cotizacionService.create(request);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(response.id()).toUri();
        return ResponseEntity.created(location).body(response);
    }
    /** Gets a quotation and its lines. */
    @GetMapping("/{id}") public ResponseEntity<CotizacionResponseDTO> findById(@PathVariable UUID id) { return ResponseEntity.ok(cotizacionService.findById(id)); }
    /** Searches quotations with pagination. */
    @GetMapping public ResponseEntity<Page<CotizacionListadoDTO>> search(@RequestParam(required=false) UUID clienteId, @RequestParam(required=false) UUID sedeId, @RequestParam(required=false) EstadoCotizacion estado, @RequestParam(required=false) @DateTimeFormat(iso=DateTimeFormat.ISO.DATE_TIME) LocalDateTime desde, @RequestParam(required=false) @DateTimeFormat(iso=DateTimeFormat.ISO.DATE_TIME) LocalDateTime hasta, @PageableDefault(size=20, sort="createdAt") Pageable pageable) { return ResponseEntity.ok(cotizacionService.search(clienteId,sedeId,estado,desde,hasta,pageable)); }
    /** Updates an issued quotation. */
    @PutMapping("/{id}") @PreAuthorize("hasAnyRole('ADMIN', 'MULTIFUNCIONAL')") public ResponseEntity<CotizacionResponseDTO> update(@PathVariable UUID id, @Valid @RequestBody CotizacionRequestDTO request) { return ResponseEntity.ok(cotizacionService.update(id, request)); }
    /** Deletes an issued quotation draft. */
    @DeleteMapping("/{id}") @PreAuthorize("hasAnyRole('ADMIN', 'MULTIFUNCIONAL')") public ResponseEntity<Void> delete(@PathVariable UUID id) { cotizacionService.delete(id); return ResponseEntity.noContent().build(); }
    /** Accepts an issued quotation. */
    @PostMapping("/{id}/aceptar") @PreAuthorize("hasAnyRole('ADMIN', 'MULTIFUNCIONAL')") public ResponseEntity<CotizacionResponseDTO> aceptar(@PathVariable UUID id) { return ResponseEntity.ok(cotizacionService.aceptar(id)); }
    /** Rejects an issued quotation. */
    @PostMapping("/{id}/rechazar") @PreAuthorize("hasAnyRole('ADMIN', 'MULTIFUNCIONAL')") public ResponseEntity<CotizacionResponseDTO> rechazar(@PathVariable UUID id, @Valid @RequestBody RechazarCotizacionRequestDTO request) { return ResponseEntity.ok(cotizacionService.rechazar(id, request)); }
    /** Converts an accepted quotation to the protected POS flow. */
    @PostMapping("/{id}/convertir") @PreAuthorize("hasAnyRole('ADMIN', 'MULTIFUNCIONAL')") public ResponseEntity<VentaProcesadaResponseDTO> convertir(@PathVariable UUID id, @Valid @RequestBody ConvertirCotizacionRequestDTO request) { return ResponseEntity.ok(cotizacionService.convertir(id, request)); }
    /** Lists and transitions expired issued quotations. */
    @GetMapping("/vencidas") public ResponseEntity<List<CotizacionListadoDTO>> vencidas() { return ResponseEntity.ok(cotizacionService.vencidas()); }
    /** Returns commercial dashboard counters. */
    @GetMapping("/dashboard") public ResponseEntity<Map<String,Object>> dashboard() { return ResponseEntity.ok(cotizacionService.dashboard()); }
}
