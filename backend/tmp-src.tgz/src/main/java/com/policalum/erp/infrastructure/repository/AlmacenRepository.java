package com.policalum.erp.infrastructure.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.policalum.erp.domain.model.Almacen;

@Repository
public interface AlmacenRepository extends JpaRepository<Almacen, UUID> {

    @EntityGraph(attributePaths = "sede")
    @Query("SELECT a FROM Almacen a WHERE "
            + "(:searchTerm IS NULL OR TRIM(:searchTerm) = '' OR "
            + "LOWER(a.nombre) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR "
            + "LOWER(COALESCE(a.descripcion, '')) LIKE LOWER(CONCAT('%', :searchTerm, '%'))) AND "
            + "(:sedeId IS NULL OR a.sede.id = :sedeId) AND "
            + "(:activo IS NULL OR a.activo = :activo)")
    Page<Almacen> search(@Param("searchTerm") String searchTerm,
            @Param("sedeId") UUID sedeId,
            @Param("activo") Boolean activo,
            Pageable pageable);

    @EntityGraph(attributePaths = "sede")
    List<Almacen> findBySede_IdOrderByNombreAsc(UUID sedeId);

    @EntityGraph(attributePaths = "sede")
    Optional<Almacen> findWithSedeById(UUID id);

    boolean existsBySede_IdAndNombreIgnoreCase(UUID sedeId, String nombre);

    Optional<Almacen> findBySede_IdAndNombreIgnoreCase(UUID sedeId, String nombre);

    long countByActivo(Boolean activo);

    long countBySede_Id(UUID sedeId);
}
