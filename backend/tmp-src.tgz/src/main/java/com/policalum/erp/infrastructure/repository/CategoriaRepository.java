package com.policalum.erp.infrastructure.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.policalum.erp.domain.model.Categoria;

@Repository
public interface CategoriaRepository extends JpaRepository<Categoria, UUID> {

    @Query("SELECT c FROM Categoria c WHERE "
            + "(:searchTerm IS NULL OR TRIM(:searchTerm) = '' OR "
            + "LOWER(c.nombre) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR "
            + "LOWER(c.slug) LIKE LOWER(CONCAT('%', :searchTerm, '%'))) AND "
            + "(:activa IS NULL OR c.activa = :activa)")
    Page<Categoria> search(@Param("searchTerm") String searchTerm,
            @Param("activa") Boolean activa,
            Pageable pageable);

    @EntityGraph(attributePaths = "parent")
    Optional<Categoria> findWithParentById(UUID id);

    List<Categoria> findByParent_IdOrderByNombreAsc(UUID parentId);

    List<Categoria> findByParentIsNullOrderByNombreAsc();

    Optional<Categoria> findBySlugIgnoreCase(String slug);

    boolean existsBySlugIgnoreCase(String slug);

    long countByActiva(Boolean activa);
}
