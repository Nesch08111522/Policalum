package com.policalum.erp.infrastructure.controller;

import com.policalum.erp.application.dto.request.AnularCompraRequestDTO;
import com.policalum.erp.application.dto.request.CompraRequestDTO;
import com.policalum.erp.application.dto.request.RecepcionCompraRequestDTO;
import com.policalum.erp.application.dto.response.CompraAdjuntoResponseDTO;
import com.policalum.erp.application.dto.response.CompraListadoDTO;
import com.policalum.erp.application.dto.response.CompraResponseDTO;
import com.policalum.erp.application.service.CompraAdjuntoService;
import com.policalum.erp.application.service.CompraService;
import com.policalum.erp.domain.enums.EstadoCompra;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/compras")
@RequiredArgsConstructor
public class CompraController {

    private final CompraService compraService;
    private final CompraAdjuntoService adjuntoService;

    // ============ COMPRAS ============

    @PostMapping
    public ResponseEntity<CompraResponseDTO> crear(@Valid @RequestBody CompraRequestDTO dto) {
        CompraResponseDTO response = compraService.crear(dto);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}").buildAndExpand(response.id()).toUri();
        return ResponseEntity.created(location).body(response);
    }

    @PutMapping("/{id}")
    public ResponseEntity<CompraResponseDTO> actualizar(
            @PathVariable UUID id, @Valid @RequestBody CompraRequestDTO dto) {
        return ResponseEntity.ok(compraService.actualizar(id, dto));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CompraResponseDTO> obtener(@PathVariable UUID id) {
        return ResponseEntity.ok(compraService.obtener(id));
    }

    @GetMapping
    public ResponseEntity<Page<CompraListadoDTO>> buscar(
            @RequestParam(required = false) UUID proveedorId,
            @RequestParam(required = false) UUID sedeId,
            @RequestParam(required = false) EstadoCompra estado,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta,
            @PageableDefault(size = 20, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable) {
        return ResponseEntity.ok(compraService.buscar(proveedorId, sedeId, estado, desde, hasta, pageable));
    }

    @PostMapping("/{id}/recepcion")
    public ResponseEntity<CompraResponseDTO> recibir(
            @PathVariable UUID id,
            @Valid @RequestBody(required = false) RecepcionCompraRequestDTO dto) {
        return ResponseEntity.ok(compraService.recibir(id, dto));
    }

    @PostMapping("/{id}/anulacion")
    public ResponseEntity<CompraResponseDTO> anular(
            @PathVariable UUID id, @Valid @RequestBody AnularCompraRequestDTO dto) {
        return ResponseEntity.ok(compraService.anular(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable UUID id) {
        compraService.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> dashboard() {
        return ResponseEntity.ok(compraService.dashboard());
    }

    // ============ ADJUNTOS ============

    @PostMapping(value = "/{id}/adjuntos", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<CompraAdjuntoResponseDTO> subirAdjunto(
            @PathVariable UUID id,
            @RequestParam("archivo") MultipartFile archivo,
            @RequestParam(value = "tipo", defaultValue = "OTRO") String tipo) {
        return ResponseEntity.status(201).body(adjuntoService.subir(id, archivo, tipo));
    }

    @GetMapping("/{id}/adjuntos")
    public ResponseEntity<List<CompraAdjuntoResponseDTO>> listarAdjuntos(@PathVariable UUID id) {
        return ResponseEntity.ok(adjuntoService.listar(id));
    }

    @GetMapping("/{id}/adjuntos/{adjuntoId}")
    public ResponseEntity<Resource> descargarAdjunto(
            @PathVariable UUID id, @PathVariable UUID adjuntoId) {
        Resource resource = adjuntoService.descargar(id, adjuntoId);
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }

    @DeleteMapping("/{id}/adjuntos/{adjuntoId}")
    public ResponseEntity<Void> eliminarAdjunto(
            @PathVariable UUID id, @PathVariable UUID adjuntoId) {
        adjuntoService.eliminar(id, adjuntoId);
        return ResponseEntity.noContent().build();
    }
}