package com.policalum.erp.infrastructure.repository;

import com.policalum.erp.domain.enums.AccionAudit;
import com.policalum.erp.domain.model.AuditLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, UUID> {

    @EntityGraph(attributePaths = {"user"})
    @Query("SELECT a FROM AuditLog a WHERE " +
            "(:tabla IS NULL OR a.tabla = :tabla) AND " +
            "(:registroId IS NULL OR a.registroId = :registroId) AND " +
            "(:userId IS NULL OR a.user.id = :userId) AND " +
            "(:accion IS NULL OR a.accion = :accion) AND " +
            "(:desde IS NULL OR a.createdAt >= :desde) AND " +
            "(:hasta IS NULL OR a.createdAt <= :hasta)")
    Page<AuditLog> search(
            @Param("tabla") String tabla,
            @Param("registroId") UUID registroId,
            @Param("userId") UUID userId,
            @Param("accion") AccionAudit accion,
            @Param("desde") LocalDateTime desde,
            @Param("hasta") LocalDateTime hasta,
            Pageable pageable);

    @EntityGraph(attributePaths = {"user"})
    List<AuditLog> findByTablaAndRegistroIdOrderByCreatedAtDesc(String tabla, UUID registroId);
}