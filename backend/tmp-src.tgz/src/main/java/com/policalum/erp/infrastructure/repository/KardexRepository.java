package com.policalum.erp.infrastructure.repository;

import java.time.LocalDateTime;
import java.util.UUID;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.policalum.erp.domain.model.KardexMovimiento;
import com.policalum.erp.domain.enums.TipoReferencia;

@Repository
public interface KardexRepository extends JpaRepository<KardexMovimiento, UUID> {

    @EntityGraph(attributePaths = {"producto", "almacen", "user"})
    @Query("SELECT k FROM KardexMovimiento k WHERE " +
            "(:productoId IS NULL OR k.producto.id = :productoId) AND " +
            "(:almacenId IS NULL OR k.almacen.id = :almacenId) AND " +
            "(:fechaInicio IS NULL OR k.createdAt >= :fechaInicio) AND " +
            "(:fechaFin IS NULL OR k.createdAt <= :fechaFin)")
    Page<KardexMovimiento> searchMovimientos(
            @Param("productoId") UUID productoId,
            @Param("almacenId") UUID almacenId,
            @Param("fechaInicio") LocalDateTime fechaInicio,
            @Param("fechaFin") LocalDateTime fechaFin,
            Pageable pageable
    );

    @EntityGraph(attributePaths = {"producto", "almacen", "user"})
    List<KardexMovimiento> findByReferenciaIdAndTipoReferencia(UUID referenciaId, TipoReferencia tipoReferencia);
}
