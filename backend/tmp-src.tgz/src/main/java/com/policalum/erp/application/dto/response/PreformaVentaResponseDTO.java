package com.policalum.erp.application.dto.response;

import com.policalum.erp.domain.enums.EstadoPreforma;
import com.policalum.erp.domain.model.Cliente;
import com.policalum.erp.domain.model.Cotizacion;
import com.policalum.erp.domain.model.PreformaVenta;
import com.policalum.erp.domain.model.Sede;
import com.policalum.erp.domain.model.TurnoCaja;
import com.policalum.erp.domain.model.User;
import com.policalum.erp.domain.model.Venta;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public record PreformaVentaResponseDTO(
        UUID id,
        Sede sede,
        User user,
        Cliente cliente,
        Cotizacion cotizacion,
        TurnoCaja turnoCaja,
        BigDecimal subtotalNetoEstimado,
        BigDecimal totalIgvEstimado,
        BigDecimal totalEstimado,
        EstadoPreforma estado,
        LocalDateTime fechaExpiracion,
        String observaciones,
        Venta venta
) {
}
