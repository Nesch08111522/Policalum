package com.policalum.erp.infrastructure.repository;

import com.policalum.erp.domain.enums.MetodoPago;
import com.policalum.erp.domain.model.PagoVenta;
import java.math.BigDecimal;
import java.util.UUID;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface PagoVentaRepository extends JpaRepository<PagoVenta, UUID> {
    @Query("select coalesce(sum(p.monto), 0) from PagoVenta p where p.venta.turnoCaja.id = :turnoId and p.metodoPago = :metodo")
    BigDecimal sumMontoByTurnoAndMetodo(@Param("turnoId") UUID turnoId, @Param("metodo") MetodoPago metodo);
    List<PagoVenta> findByVenta_Id(UUID ventaId);
}
